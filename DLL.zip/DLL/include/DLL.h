#ifndef DLL_H
#define DLL_H
#include <iostream>
#include <conio.h>
#include <stdlib.h>
using namespace std;
template <class t>
class DLL
{
public:
    DLL();
    bool isempty();
    void addToHead (t item);
    void addToTail (t item);
    void addToIndex(t item, t index);
    bool search (t item);
    void removeItem (t item);
    void removeHead ();
    void removeTail ();
    void reverse ();
    void sort(bool comp(double a,double b));
    void print();
    virtual ~DLL();

protected:

private:
    struct node
    {
        t element;
        node *next;
        node *prev;
    };
    int count;
    node *head;
    node *tail;
};

#endif // DLL_H
