#include "DLL.h"
#include <iostream>
#include <conio.h>
#include <stdlib.h>
using namespace std;
template<class t>
DLL<t>::DLL()
{
    head=tail=NULL;
    count =0;
}
template<class t>
bool DLL<t>::isempty()
{
    return count==0;
}
template<class t>
void DLL<t>::addToHead(t item)
{
    node*newnode=new node;
    newnode->element=item;
    if(count==0)
    {
        head=tail=newnode;
        newnode->next=newnode->prev=NULL;
    }
    else
    {
        newnode->next=head;
        head->prev=newnode;
        head=newnode;
        newnode->prev=NULL;
    }
    count++;
}
template<class t>
void DLL<t>::addToTail(t item)
{
    node*newnode=new node;
    newnode->element=item;
    if(count==0)
    {
        head=tail=newnode;
        newnode->next=newnode->prev=NULL;
    }
    else
    {
        newnode->prev=tail;
        tail->next=newnode;
        newnode->next=NULL;
        tail=newnode;
    }
    count++;
}
template<class t>
void DLL<t>::addToIndex(t item,t index)
{
    if(index<0||index>count)
        cout<<"out of range ."<<endl;
    else
    {
        node*newnode=new node;
        newnode->element=item;
        if(index==0)
            addToHead(item);
        else if(index==count)
            addToTail(item);
        else
        {
            node*ptr;
            ptr=head;
            for(t i=1; i<index; i++)
                ptr=ptr->next;
            newnode->next=ptr->next;
            newnode->prev=ptr;
            ptr->next->prev=newnode;
            ptr->next=newnode;
            count++;
        }
    }
}
template<class t>
bool DLL<t>::search(t item)
{
    node*ptr=head;
    while(ptr!=NULL)
        ptr=ptr->next;
    if(ptr!=NULL)
        return true;
    else
        return false;
}
template<class t>
void DLL<t>::removeHead( )
{
    if(count==0)
        cout<<"Empty List."<<endl;
    else if(count==1)
    {
        delete head;
        head=tail=NULL;
    }
    else
    {
        node*ptr;
        ptr=head;
        head=head->next;
        head->prev=NULL;
        delete ptr;
    }
    count--;
}
template<class t>
void DLL<t>::removeTail( )
{
    if(count==0)
        cout<<"Empty List."<<endl;
    else if(count==1)
    {
        delete head;
        head=tail=NULL;
    }
    else
    {
        node*ptr;
        ptr=tail;
        tail=tail->prev;
        tail->next=NULL;
        delete ptr;
    }
    count--;
}
template<class t>
void DLL<t>::removeItem(t item)
{
    if(count==0)
        cout<<"Empty List."<<endl;
    if(head->element=item)
        removeHead( );
    else
    {
        node*ptr=head->next;
        while(ptr!=NULL)
        {
            if(ptr->element==item)
                break;
            ptr=ptr->next;
        }
        if(ptr==NULL)
            cout<<"Item not there."<<endl;
        else if(ptr->next==NULL)
            removeTail( );
        else
        {
            ptr->prev->next=ptr->next;
            ptr->next->prev=ptr->prev;
            delete ptr;
            count--;
        }
    }
}
template<class t>
void DLL<t>::reverse()
{
    node*ptr=tail;
    while(ptr!=NULL)
    {
        cout<<ptr->element<<" ";
        ptr=ptr->prev;
    }
    cout<<endl;
}
template<class t>
void DLL<t>::print()
{
    node*ptr=head;
    while(ptr!=NULL)
    {
        cout<<ptr->element<<" ";
        ptr=ptr->next;
    }
    cout<<endl;
}
template<class t>
void DLL<t>::sort(bool comp(double a,double b))
{
    node* n=new node;

    for(int i=0; i<count; i++)
    {
        n=head->next;
        t temp;
        while(n!=NULL)
        {
            if(comp(n->element,n->prev->element)==true)
            {
                temp=n->prev->element;
                n->prev->element=n->element;
                n->element=temp;
            }
            n=n->next;
        }
    }
}
template<class t>
DLL<t>::~DLL()
{
    //dtor
}
