#include <iostream>
#include "src\DLL.cpp"
#include <list>
#include <conio.h>
using namespace std;

bool comp(double a,double b)
{
    if(a<b)
        return true;
    else
        return false;
}
int main()
{
    DLL<double> d;
    d.addToHead(7);
    d.addToHead(11);
    d.addToTail(3);
    d.addToTail(7);
    d.addToHead(15);
    cout<<"Tho out put is :"<<endl;
    cout<<"After adding 7 to head"<<endl;
    cout<<"After adding 11 to head"<<endl;
    cout<<"After adding 3 to tail"<<endl;
    cout<<"After adding 7 to tail"<<endl;
    cout<<"After adding 15 to head"<<endl<<endl;
    d.print();
    cout<<endl<<endl<<"Tho out put after reversing is :"<<endl<<endl;
    d.reverse();
    cout<<endl<<endl<<"Tho out put after Sorting it :"<<endl<<endl;
    d.sort(comp);
    d.print();
}
